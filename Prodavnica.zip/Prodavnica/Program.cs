using Prodavnica.Controllers;
using Prodavnica.Models;
using Prodavnica.Views;

namespace Prodavnica;

class Program
{
    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        var controller = new ProdavnicaController();
        var view = new ProdavnicaView();

        view.PrikaziDobrodoslicu();

        bool unosZavrsen = false;
        while (!unosZavrsen)
        {
            view.PrikaziOpcijeUnosa(controller.BrojStavki);
            string? izbor = Console.ReadLine();

            switch (izbor?.Trim())
            {
                case "1":
                    DodajStavku(controller, view);
                    break;
                case "0":
                    if (controller.BrojStavki == 0)
                    {
                        view.IspisiGresku("Korpa je prazna. Morate unijeti bar jednu stavku.");
                        break;
                    }
                    unosZavrsen = true;
                    break;
                default:
                    view.IspisiUpozorenje("Nepoznata opcija. Unesite 1 ili 0.");
                    break;
            }
        }

        string? kupon = ProcitajKupon(view);
        ProdavnicaRezultat rezultat;
        try
        {
            rezultat = controller.IzracunajRezultat(kupon);
        }
        catch (Exception ex)
        {
            view.IspisiGresku($"Greska: {ex.Message}");
            return;
        }

        if (rezultat.KuponNevalidan)
        {
            view.IspisiUpozorenje("Kupon nije vazeci, ignorisan je. Dozvoljen kupon je: STUDENT10.");
        }

        view.PrikaziRezultat(rezultat);
        view.IspisiPoruku("Pritisnite Enter za izlaz...");
        Console.ReadLine();
    }

    static void DodajStavku(ProdavnicaController controller, ProdavnicaView view)
    {
        string naziv = ProcitajNeprazanString("Unesite naziv artikla: ", "Naziv ne moze biti prazan.", view);
        decimal cijena = ProcitajDecimal("Unesite jedinicnu cijenu (KM): ", view);
        int kolicina = ProcitajInt("Unesite kolicinu: ", view);
        KategorijaArtikla kategorija = ProcitajKategoriju(view);
        bool naAkciji = ProcitajDaNe("Da li je artikal na akciji (DA/NE): ", view);

        try
        {
            controller.DodajStavku(naziv, cijena, kolicina, kategorija, naAkciji);
            view.IspisiUspjeh("Stavka je dodana u korpu.");
        }
        catch (Exception ex)
        {
            view.IspisiGresku($"Greska: {ex.Message}");
        }
    }

    static string ProcitajNeprazanString(string prompt, string error, ProdavnicaView view)
    {
        while (true)
        {
            Console.Write(prompt);
            string? input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input))
            {
                return input.Trim();
            }
            view.IspisiGresku(error);
        }
    }

    static decimal ProcitajDecimal(string prompt, ProdavnicaView view)
    {
        while (true)
        {
            Console.Write(prompt);
            string? input = Console.ReadLine();
            if (decimal.TryParse(input, out decimal vrijednost) && vrijednost > 0m)
            {
                return vrijednost;
            }
            view.IspisiGresku("Cijena mora biti broj veci od 0.");
        }
    }

    static int ProcitajInt(string prompt, ProdavnicaView view)
    {
        while (true)
        {
            Console.Write(prompt);
            string? input = Console.ReadLine();
            if (int.TryParse(input, out int vrijednost) && vrijednost > 0)
            {
                return vrijednost;
            }
            view.IspisiGresku("Kolicina mora biti cijeli broj veci od 0.");
        }
    }

    static KategorijaArtikla ProcitajKategoriju(ProdavnicaView view)
    {
        while (true)
        {
            view.PrikaziKategorije();
            Console.Write("Unesite kategoriju (broj ili naziv): ");
            string? input = Console.ReadLine();

            if (TryParseKategorija(input, out KategorijaArtikla kategorija))
            {
                return kategorija;
            }

            view.IspisiGresku("Nevalidna kategorija. Pokusajte ponovo.");
        }
    }

    static bool TryParseKategorija(string? input, out KategorijaArtikla kategorija)
    {
        kategorija = default;
        if (string.IsNullOrWhiteSpace(input))
        {
            return false;
        }

        string trimmed = input.Trim();
        if (int.TryParse(trimmed, out int id))
        {
            if (Enum.IsDefined(typeof(KategorijaArtikla), id))
            {
                kategorija = (KategorijaArtikla)id;
                return true;
            }
            return false;
        }

        if (Enum.TryParse(trimmed, true, out KategorijaArtikla parsed) &&
            Enum.IsDefined(typeof(KategorijaArtikla), parsed))
        {
            kategorija = parsed;
            return true;
        }

        return false;
    }

    static bool ProcitajDaNe(string prompt, ProdavnicaView view)
    {
        while (true)
        {
            Console.Write(prompt);
            string? input = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(input))
            {
                view.IspisiGresku("Unesite DA ili NE.");
                continue;
            }

            string value = input.Trim().ToLowerInvariant();
            if (value == "da" || value == "d")
            {
                return true;
            }
            if (value == "ne" || value == "n")
            {
                return false;
            }

            view.IspisiGresku("Unesite DA ili NE.");
        }
    }

    static string? ProcitajKupon(ProdavnicaView view)
    {
        view.PrikaziUputstvoKupon();
        string? input = Console.ReadLine();
        if (string.IsNullOrWhiteSpace(input))
        {
            return null;
        }
        return input.Trim();
    }
}
