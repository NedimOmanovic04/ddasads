using Prodavnica.Models;

namespace Prodavnica.Controllers;

public class ProdavnicaController
{
    private readonly List<StavkaKorpe> stavke = new();

    public int BrojStavki => stavke.Count;

    public IReadOnlyList<StavkaKorpe> GetStavke() => stavke.AsReadOnly();

    public void DodajStavku(string naziv, decimal cijena, int kolicina, KategorijaArtikla kategorija, bool naAkciji)
    {
        if (string.IsNullOrWhiteSpace(naziv))
        {
            throw new ArgumentException("Naziv ne moze biti prazan.");
        }

        if (cijena <= 0m)
        {
            throw new ArgumentException("Cijena mora biti veca od nule.");
        }

        if (kolicina <= 0)
        {
            throw new ArgumentException("Kolicina mora biti veca od nule.");
        }

        var stavka = new StavkaKorpe(naziv, cijena, kolicina, kategorija, naAkciji);
        stavke.Add(stavka);
    }

    public ProdavnicaRezultat IzracunajRezultat(string? kuponKod)
    {
        if (stavke.Count == 0)
        {
            throw new InvalidOperationException("Korpa nema nijednu stavku.");
        }

        decimal subtotal = stavke.Sum(stavka => stavka.UkupnaVrijednost());
        decimal osnovicaZaPopust = stavke
            .Where(stavka => !stavka.NaAkciji)
            .Sum(stavka => stavka.UkupnaVrijednost());

        bool kuponValidan = false;
        bool kuponNevalidan = false;
        if (!string.IsNullOrWhiteSpace(kuponKod))
        {
            string kod = kuponKod.Trim();
            if (string.Equals(kod, "STUDENT10", StringComparison.OrdinalIgnoreCase))
            {
                kuponValidan = true;
            }
            else
            {
                kuponNevalidan = true;
            }
        }

        decimal popust = 0m;
        PopustTip tip = PopustTip.Nijedan;
        string? objasnjenje = null;

        if (kuponValidan && osnovicaZaPopust > 0m)
        {
            popust = osnovicaZaPopust * 0.10m;
            if (popust > 30.00m)
            {
                popust = 30.00m;
            }
            tip = PopustTip.Kupon;
            objasnjenje = "Kupon ima prednost nad threshold popustom.";
        }
        else
        {
            if (osnovicaZaPopust >= 200.00m)
            {
                popust = osnovicaZaPopust * 0.10m;
                tip = PopustTip.Threshold;
            }
            else if (osnovicaZaPopust >= 100.00m)
            {
                popust = osnovicaZaPopust * 0.05m;
                tip = PopustTip.Threshold;
            }
        }

        decimal maxPopust = osnovicaZaPopust * 0.20m;
        if (popust > maxPopust)
        {
            popust = maxPopust;
        }

        decimal total = subtotal - popust;

        return new ProdavnicaRezultat(subtotal, popust, total, tip, objasnjenje, kuponNevalidan);
    }
}
