﻿namespace Prodavnica.Models
{
    public enum KategorijaArtikla
    {
        Hrana = 1,
        Tehnika = 2,
        Knjige = 3,
        Ostalo = 4
    }
}
