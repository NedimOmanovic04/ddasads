﻿namespace Prodavnica.Models
{
    public class Artikal
    {
        public int ArtikalId { get; set; }
        public string Naziv { get; set; }
        public string Opis { get; set; }
        public decimal Cijena { get; set; }
        public int KolicinaNaStanju { get; set; }
        public int KategorijaId { get; set; }

        public Artikal(int artikalId, string naziv, string opis, decimal cijena, int kolicinaNaStanju, int kategorijaId)
        {
            ArtikalId = artikalId;
            Naziv = naziv;
            Opis = opis;
            Cijena = cijena;
            KolicinaNaStanju = kolicinaNaStanju;
            KategorijaId = kategorijaId;
        }

        /// <summary>
        /// Izračunava ukupnu vrijednost artikla (cijena * količina)
        /// </summary>
        public decimal UkupnaVrijednost()
        {
            return Cijena * KolicinaNaStanju;
        }

        public override string ToString()
        {
            return $"[ID: {ArtikalId}] {Naziv} - Cijena: {Cijena:F2} KM, Količina: {KolicinaNaStanju}, Kategorija ID: {KategorijaId}";
        }
    }
}
