﻿namespace Prodavnica.Models
{
    public class StavkaKorpe
    {
        public string Naziv { get; }
        public decimal Cijena { get; }
        public int Kolicina { get; }
        public KategorijaArtikla Kategorija { get; }
        public bool NaAkciji { get; }

        public StavkaKorpe(string naziv, decimal cijena, int kolicina, KategorijaArtikla kategorija, bool naAkciji)
        {
            Naziv = naziv;
            Cijena = cijena;
            Kolicina = kolicina;
            Kategorija = kategorija;
            NaAkciji = naAkciji;
        }

        public decimal UkupnaVrijednost() => Cijena * Kolicina;
    }
}
