namespace Prodavnica.Models
{
    public enum PopustTip
    {
        Nijedan,
        Threshold,
        Kupon
    }

    public sealed class ProdavnicaRezultat
    {
        public decimal Subtotal { get; }
        public decimal Popust { get; }
        public decimal Total { get; }
        public PopustTip TipPopusta { get; }
        public string? Objasnjenje { get; }
        public bool KuponNevalidan { get; }

        public ProdavnicaRezultat(
            decimal subtotal,
            decimal popust,
            decimal total,
            PopustTip tipPopusta,
            string? objasnjenje,
            bool kuponNevalidan)
        {
            Subtotal = subtotal;
            Popust = popust;
            Total = total;
            TipPopusta = tipPopusta;
            Objasnjenje = objasnjenje;
            KuponNevalidan = kuponNevalidan;
        }
    }

}
