﻿# Prodavnica - konzolna aplikacija

## Pregled
Ova aplikacija je jednostavna konzolna kasa (obracun korpe). Korisnik unosi stavke u korpu, a zatim aplikacija izracunava subtotal, popust i konacni iznos. 
Podrzan je kupon `STUDENT10` i threshold popusti. 
Kupon/threshold se ne primjenjuju na stavke koje su vec na akciji.

## Kako radi (koraci)
1. Aplikacija prikazuje dobrodoslicu i meni.
2. Korisnik unosi stavke (naziv, cijena, kolicina, kategorija, da li je na akciji).
3. Unos se zavrsava kada korisnik izabere opciju `0`.
4. Aplikacija trazi opcionalni kupon.
5. Izracunava se rezultat (subtotal, popust, total).
6. Ako je kupon nevalidan, korisnik dobija upozorenje.
7. Prikazuje se rezultat i aplikacija ceka Enter za izlaz.

## Pravila popusta
- **Kupon**: `STUDENT10` daje 10% popusta na stavke koje nisu na akciji, maksimalno 30.00 KM.
- **Threshold**: ako kupon nije validan/unesen, primjenjuje se:
  - 10% ako osnovica >= 200.00 KM
  - 5% ako osnovica >= 100.00 KM
- **Osnovica za popust**: samo stavke koje *nisu* na akciji.
- **Maksimalni popust**: 20% od osnovice za popust.

## Struktura projekta
- `Program.cs` - ulazna tacka i tok aplikacije
- `Controllers/ProdavnicaController.cs` - logika korpe i obracun popusta
- `View/ProdavnicaView.cs` - ispis u konzoli
- `Models/` - modeli domene (stavka, kategorija, rezultat)

## Detaljno: funkcije po fajlu

### `Program.cs`
- `Main(string[] args)`
  - Ulazna tacka aplikacije.
  - Kreira `ProdavnicaController` i `ProdavnicaView`.
  - Vodi korisnika kroz unos stavki, uzima kupon i prikazuje rezultat.

- `DodajStavku(ProdavnicaController controller, ProdavnicaView view)`
  - Prikuplja podatke o jednoj stavci i dodaje je u korpu.
  - Obradjuje izuzetke i prikazuje poruke.

- `ProcitajNeprazanString(string prompt, string error, ProdavnicaView view)`
  - Cita string dok korisnik ne unese ne-praznu vrijednost.

- `ProcitajDecimal(string prompt, ProdavnicaView view)`
  - Cita decimalni broj > 0 (cijena).

- `ProcitajInt(string prompt, ProdavnicaView view)`
  - Cita cijeli broj > 0 (kolicina).

- `ProcitajKategoriju(ProdavnicaView view)`
  - Prikazuje kategorije i citanjem bira validnu kategoriju.

- `TryParseKategorija(string? input, out KategorijaArtikla kategorija)`
  - Parsira unos u `KategorijaArtikla` (po id ili nazivu).

- `ProcitajDaNe(string prompt, ProdavnicaView view)`
  - Cita odgovor `DA/NE` i vraca `true/false`.

- `ProcitajKupon(ProdavnicaView view)`
  - Cita kupon; vraca `null` ako je unos prazan.

### `Controllers/ProdavnicaController.cs`
- `BrojStavki`
  - Broj stavki trenutno u korpi.

- `GetStavke()`
  - Vraca read-only listu stavki (nema izmjena izvana).

- `DodajStavku(string naziv, decimal cijena, int kolicina, KategorijaArtikla kategorija, bool naAkciji)`
  - Validira ulaz i dodaje novu stavku u korpu.

- `IzracunajRezultat(string? kuponKod)`
  - Racuna subtotal svih stavki.
  - Racuna osnovicu za popust samo za stavke koje nisu na akciji.
  - Primjenjuje kupon ili threshold, uz ogranicenja.
  - Vraca `ProdavnicaRezultat`.

### `View/ProdavnicaView.cs`
- `PrikaziDobrodoslicu()`
  - Ispis zaglavlja aplikacije.

- `PrikaziOpcijeUnosa(int brojStavki)`
  - Ispis menija za unos stavki.

- `PrikaziUputstvoKupon()`
  - Ispis uputstva za kupon.

- `PrikaziKategorije()`
  - Ispis svih dostupnih kategorija.

- `IspisiPoruku(string poruka)`
  - Genericki ispis teksta.

- `IspisiUspjeh(string poruka)`
  - Zeleni tekst za uspjeh.

- `IspisiUpozorenje(string poruka)`
  - Zuti tekst za upozorenja.

- `IspisiGresku(string poruka)`
  - Crveni tekst za greske.

- `PrikaziRezultat(ProdavnicaRezultat rezultat)`
  - Prikazuje subtotal, tip popusta, iznos popusta i total.

### `Models/Artikal.cs`
- `Artikal` model opisuje artikal u katalogu (nije direktno koristen u korpi).
- `UkupnaVrijednost()` racuna `Cijena * KolicinaNaStanju`.
- `ToString()` formatira prikaz artikla.

### `Models/StavkaKorpe.cs`
- `StavkaKorpe` model jedne stavke u korpi.
- `UkupnaVrijednost()` racuna `Cijena * Kolicina`.

### `Models/Kategorija.cs`
- `KategorijaArtikla` enum sa kategorijama.

### `Models/ProdavnicaRezultat.cs`
- `PopustTip` enum: `Nijedan`, `Threshold`, `Kupon`.
- `ProdavnicaRezultat` sadrzi subtotal, popust, total, tip popusta, objasnjenje i status kupona.

## Pokretanje
U root folderu projekta:
```powershell
 dotnet run
```

## Napomena
Aplikacija koristi konzolni unos/ispis i radi potpuno lokalno.
