using Prodavnica.Models;

namespace Prodavnica.Views;

public class ProdavnicaView
{
    public void PrikaziDobrodoslicu()
    {
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("==============================================");
        Console.WriteLine("        APLIKACIJA ZA OBRACUN KORPE");
        Console.WriteLine("                    Verzija 1.0");
        Console.WriteLine("==============================================");
        Console.ResetColor();
    }

    public void PrikaziOpcijeUnosa(int brojStavki)
    {
        Console.WriteLine();
        Console.WriteLine("Opcije:");
        Console.WriteLine("  1. Dodaj artikal");
        Console.WriteLine("  0. Zavrsi unos");
        Console.WriteLine($"Trenutno stavki u korpi: {brojStavki}");
        Console.Write("Unesite opciju: ");
    }

    public void PrikaziUputstvoKupon()
    {
        Console.WriteLine();
        Console.WriteLine("Kupon je opcionalan. Unesite STUDENT10 za 10% popusta (max 30.00 KM).");
        Console.WriteLine("Ako nemate kupon, pritisnite Enter bez unosa.");
        Console.Write("Unesite kupon: ");
    }

    public void PrikaziKategorije()
    {
        Console.WriteLine();
        Console.WriteLine("Kategorije:");
        foreach (var kategorija in Enum.GetValues<KategorijaArtikla>())
        {
            Console.WriteLine($"  {(int)kategorija}. {kategorija}");
        }
    }

    public void IspisiPoruku(string poruka)
    {
        Console.WriteLine(poruka);
    }

    public void IspisiUspjeh(string poruka)
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine(poruka);
        Console.ResetColor();
    }

    public void IspisiUpozorenje(string poruka)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine(poruka);
        Console.ResetColor();
    }

    public void IspisiGresku(string poruka)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(poruka);
        Console.ResetColor();
    }

    public void PrikaziRezultat(ProdavnicaRezultat rezultat)
    {
        Console.WriteLine();
        Console.WriteLine("============== REZULTAT ==============");
        Console.WriteLine($"Subtotal: {rezultat.Subtotal:F2} KM");
        Console.WriteLine($"Primijenjena vrsta popusta: {FormatTip(rezultat.TipPopusta)}");
        Console.WriteLine($"Ukupan popust: {rezultat.Popust:F2} KM");
        Console.WriteLine($"Konacni total: {rezultat.Total:F2} KM");
        if (!string.IsNullOrWhiteSpace(rezultat.Objasnjenje))
        {
            Console.WriteLine();
            Console.WriteLine(rezultat.Objasnjenje);
        }
        Console.WriteLine("======================================");
    }

    private static string FormatTip(PopustTip tip)
    {
        return tip switch
        {
            PopustTip.Kupon => "kupon",
            PopustTip.Threshold => "threshold",
            _ => "nijedan"
        };
    }
}
